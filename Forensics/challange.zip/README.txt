Tidak ada apa apa di sini :}
Apa yah kira kira??
